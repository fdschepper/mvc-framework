<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'proefexamendag3');

define('APPROOT', dirname(dirname(__FILE__)));

// Zet hier je virtualhostnaam. Let op dat er http:// voor staat anders werkt het niet
define('URLROOT', 'http://proefexameniii.nl');

define('SITENAME', 'Brooklyn bowling reservaties');
