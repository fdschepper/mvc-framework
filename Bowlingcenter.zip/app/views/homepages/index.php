<?php require APPROOT . '/views/includes/head.php'; ?>
<p>
<h3><?= $data["title"]; ?></h3>
</p>
<a href="<?= URLROOT; ?>/reservations/index">Overzicht reserveringen (user story 4)</a>
<br>
<a href="<?= URLROOT; ?>/reservations/editOverview">Overzicht reserveringen (user story 8)</a>

<?php require APPROOT . '/views/includes/footer.php'; ?>